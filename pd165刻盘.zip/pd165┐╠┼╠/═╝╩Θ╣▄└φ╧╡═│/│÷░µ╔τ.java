/***********************************************************************
 * Module:  出版社.java
 * Author:  Administrator
 * Purpose: Defines the Class 出版社
 ***********************************************************************/

import java.util.*;

/** @pdOid fcfd78da-6e4e-46a2-8411-bf90b07c1da9 */
public class 出版社 {
   /** @pdOid 173a4f88-3c58-40e9-b3ed-819431629599 */
   public java.lang.String 出版社编号;
   /** @pdOid a6576bfd-4cc4-44a7-88d1-a9b5ddcde51b */
   public java.lang.String 出版社名称;
   /** @pdOid bb1b1f18-2d0b-45f8-ad95-4479589a0b76 */
   public java.lang.String 出版社地址;
   /** @pdOid 6b94285f-856f-4e43-b9ca-9a9eadcf788e */
   public java.lang.String 出版社电话;

}