/***********************************************************************
 * Module:  图书类别.java
 * Author:  Administrator
 * Purpose: Defines the Class 图书类别
 ***********************************************************************/

import java.util.*;

/** @pdOid 8d5cfc26-937d-4da1-b805-d1b9c395a0e3 */
public class 图书类别 {
   /** @pdOid 517c2fc0-6bd5-4f61-8a91-8351ab024d73 */
   public java.lang.String 图书类别编号;
   /** @pdOid b6c8c977-c90b-446d-a3cc-69a2c4755c01 */
   public java.lang.String 图书类别名称;
   /** @pdOid 7fb3efee-d291-4265-9715-90a02715a254 */
   public java.lang.String 描述;

}