/***********************************************************************
 * Module:  还.java
 * Author:  Administrator
 * Purpose: Defines the Class 还
 ***********************************************************************/

import java.util.*;

/** @pdOid c7ffe44e-871c-491f-a8b4-ac399c968913 */
public class 还 {
   /** @pdOid 47c34654-b699-4a00-9efe-b93eeff0010f */
   public java.util.Date 还书时间;
   /** @pdOid c0cd39af-e711-4a2b-9663-af1eccc7510f */
   public double 还书数量;

}