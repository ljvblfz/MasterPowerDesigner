/***********************************************************************
 * Module:  借.java
 * Author:  Administrator
 * Purpose: Defines the Class 借
 ***********************************************************************/

import java.util.*;

/** @pdOid 3cdb615f-41f4-463a-9bf2-7a86fc7044a5 */
public class 借 {
   /** @pdOid 5be42d80-af70-4939-a877-138c23807e39 */
   public java.util.Date 借书时间;
   /** @pdOid faf17b7a-31d1-43fe-b624-2103f8ed7f5c */
   public double 借书数量;

}