/***********************************************************************
 * Module:  成绩.java
 * Author:  coco
 * Purpose: Defines the Class 成绩
 ***********************************************************************/

import java.util.*;

/** @pdOid a756d7ed-ada3-4a22-8773-baf97a58c926 */
public class 成绩 {
   /** @pdOid 0651b926-8cfe-441e-b839-82a9ce2fd903 */
   public double 成绩;
   /** @pdOid 9596d831-b084-4256-9d30-502d1cfcbbc5 */
   public java.lang.String 备注;
   
   public 学生 学生-成绩;
   public 课程 课程-成绩;

}